$(document).ready(function(e) {
  
    
    windowSize();
    linkC();
});
var linkC=function(){
    
    $(".formbody").load('/book/success/'+link);
};