$(document).ready(function(e) {
   
    windowSize();

});
var index= function(){
    var url = "../bookScan/bookScanAction.action";
        deptAction(url,new Array());
    };

