/*
 * @(#)CommonDao.java
 */
package com.yuanneng.book.common.dao;

/**
 * CommonDao.java
 * 
 * 功 能： 所有DAO类的共同接口
 * 
 * <pre>
 * ver     修订日             作者            修订内容
 * 1.0     2016.03.29         meiqiong        新规做成
 * </pre>
 */
public interface CommonDao {
    // TODO 共通的处理未记入
}
