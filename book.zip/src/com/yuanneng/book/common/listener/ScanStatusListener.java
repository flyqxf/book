package com.yuanneng.book.common.listener;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.yuanneng.book.common.utils.Constant;
import com.yuanneng.book.common.utils.PropertyUtil;

/**
 * ScanStatusListener.java
 * 
 * 功 能： 扫描状态获取Listener
 * 
 * <pre>
 * ver     修订日             作者            修订内容
 * 1.0     2016.04.18         秦霄飞          新规做成
 * </pre>
 */
public class ScanStatusListener implements ServletContextListener {

    /**
     * ServletContext失效时处理
     * 
     * @param src ServletContextEvent
     */
    @Override
    public void contextDestroyed(ServletContextEvent src) {
    }

    /**
     * ServletContext初始化处理
     * 
     * @param src ServletContextEvent
     */
    @Override
    public void contextInitialized(ServletContextEvent src) {
        WebApplicationContext ac = WebApplicationContextUtils.getWebApplicationContext(src
                .getServletContext());
        Class<?>[] c = new Class[] { WebApplicationContext.class };
        Enumeration<String> en = PropertyUtil.getPropertyNames(Constant.TIMER);
        while (en.hasMoreElements()) {
            String timerStr = en.nextElement();
            String str = PropertyUtil.getProperty(timerStr);
            String[] timerInfo = str.split(Constant.COMMA);
            if (timerInfo.length == 3) {
                String serviceName = timerInfo[0];

                try {
                    Class<?> cl = Class.forName(serviceName);
                    Object scanService = cl.newInstance();
                    Method mdSet = cl.getMethod("setT", c);
                    mdSet.invoke(scanService, ac);
                    Method md = cl.getMethod(Constant.METHOD_EXCUTE);
                    md.invoke(scanService);

                } catch (IllegalArgumentException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (SecurityException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            } else {
                // TODO 异常处理
            }

        }

    }
}
