/*
 * @(#)CommonService.java
 */
package com.yuanneng.book.common.service;

/**
 * CommonService.java
 * 
 * 功 能： 所有service的共同接口
 * 
 * <pre>
 * ver     修订日             作者            修订内容
 * 1.0     2016.03.29         meiqiong        新规做成
 * </pre>
 */
public interface CommonService {

    // public interface CommonService<OUT, IN extends CommonBean> {
    /**
     * message生成用类
     */
    // @Resource
    // protected MessageHelper messageHelper;

    // TODO public OUT execute(IN obj) throws Exception;
}
